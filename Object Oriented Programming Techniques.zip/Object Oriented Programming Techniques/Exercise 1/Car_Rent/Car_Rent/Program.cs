﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car_Rent
{
    class Program
    {
        static void Main(string[] args)
        {
            rental rt = new rental("Saon", "Punnkerikatu", "12345", "Primo", DateTime.Now, DateTime.Now.AddDays(30));
            Console.WriteLine(rt.ToString());
            Console.ReadLine();
        }
        
    }
    class customer
    {
        public string name;
        public string address;
        public string contact;
        public customer()
        { }
    }
    class car:customer
    {
        public string model;
        public car() 
        { }
    }
        class rental:car
        {
            
            DateTime start= DateTime.Now;
            DateTime end = DateTime.Now.AddDays(30);
           
            public rental(string name, string address, string contact, string model,DateTime start,DateTime end)
            {
                this.name = name;
                this.address = address;
                this.contact = contact;
                this.model = model;
                this.start = start;
                this.end = end;
            }
            public override string ToString()
            {
                return "Your Car Reservation Details:\n " + "Your Name: " + name + "\n " + "Address: " + address + "\n " + "Contact: " + contact + "\n " + "Car Model: " + model + "\n " + "Researvation Start: " + start + "\n " + "Reservation End: " + end;
            }
           


        }
            
}
